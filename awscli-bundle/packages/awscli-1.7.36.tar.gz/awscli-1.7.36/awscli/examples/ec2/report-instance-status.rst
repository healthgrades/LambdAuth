**To report status feedback for an instance**

This example command reports status feedback for the specified instance.

Command::

  aws ec2 report-instance-status --instances i-570e5a28 --status impaired --reason-codes unresponsive
